import { HandRankType, Player } from '../types/game';
import { evaluateHand } from './handEvaluator';

export type AIDecisionType = 
  | 'see_cards' 
  | 'blind_bet' 
  | 'blind_raise' 
  | 'chaal_bet' 
  | 'chaal_raise' 
  | 'pack' 
  | 'show'
  | 'sideshow';

export interface AIDecision {
  action: AIDecisionType;
  amount: number;
  reason?: string;
}

export function getAIDecision(
  bot: Player,
  currentStake: number,
  activePlayersCount: number,
  roundNumber: number,
  potTotal: number
): AIDecision {
  // If bot doesn't have enough chips for minimum bet, they must pack or go all-in
  const minBlind = currentStake;
  const minChaal = currentStake * 2;

  // 1. If the bot is currently BLIND:
  if (!bot.isSeen) {
    // Decide whether to stay blind or peek cards
    // Vikram/Kabir might stay blind for 2-3 rounds; Priya/Ananya peek early.
    const seeCardProbability = 
      bot.personality === 'tight' ? 0.85 :
      bot.personality === 'balanced' ? (roundNumber > 1 ? 0.75 : 0.4) :
      bot.personality === 'bluffer' ? (roundNumber > 3 ? 0.8 : 0.2) :
      (roundNumber > 2 ? 0.7 : 0.35); // aggressive

    if (Math.random() < seeCardProbability) {
      // Bot chooses to peek cards! We will transition them to Seen, then make a seen decision
      return { action: 'see_cards', amount: 0, reason: 'Peeking at cards' };
    }

    // Bot remains Blind
    if (bot.chips < minBlind) {
      return { action: 'pack', amount: 0, reason: 'Short stacked' };
    }

    // Should they raise blind? (Double stake)
    const canRaise = bot.chips >= minBlind * 2;
    const raiseChance = bot.personality === 'bluffer' || bot.personality === 'aggressive' ? 0.3 : 0.08;

    if (canRaise && Math.random() < raiseChance) {
      return { action: 'blind_raise', amount: minBlind * 2, reason: 'Aggressive blind raise' };
    }

    return { action: 'blind_bet', amount: minBlind, reason: 'Playing blind' };
  }

  // 2. The bot is SEEN:
  const hand = evaluateHand(bot.cards);
  const { rankType, score } = hand;

  // If bot doesn't have enough chips for minimum chaal
  if (bot.chips < minChaal) {
    // If hand is exceptional, might show if 2 players left, or pack
    if (activePlayersCount === 2 && bot.chips >= minChaal) {
      return { action: 'show', amount: minChaal, reason: 'Desperation show' };
    }
    return { action: 'pack', amount: 0, reason: 'Insufficient chips' };
  }

  // Decide if bot should SHOW (only possible when exactly 2 players remain)
  if (activePlayersCount === 2) {
    // Show costs minChaal
    // If bot has a decent hand or pot is huge, they might call Show!
    if (rankType >= HandRankType.PAIR) {
      // For pairs or higher, if pot is large or round has progressed, show or chaal
      if (rankType >= HandRankType.PURE_SEQUENCE || rankType === HandRankType.TRAIL) {
        // Monster hand: chaal or raise to extract chips before showing!
        if (Math.random() < 0.4 && bot.chips >= minChaal * 2) {
          return { action: 'chaal_raise', amount: minChaal * 2, reason: 'Raising monster hand' };
        }
        return { action: 'chaal_bet', amount: minChaal, reason: 'Milking the pot' };
      }

      // Normal pairs / color / sequence: 50% show to lock in result
      if (Math.random() < 0.55) {
        return { action: 'show', amount: minChaal, reason: 'Requesting show' };
      }
    } else {
      // High card with 2 players left
      const highRank = bot.cards.map((c) => c.rank).sort((a, b) => b - a)[0];
      if (highRank >= 13 && Math.random() < 0.4) {
        // Ace or King high: 40% chance to show
        return { action: 'show', amount: minChaal, reason: 'Calling show with high card' };
      }
      if (highRank < 10 && bot.personality !== 'bluffer') {
        // Weak high card: fold!
        return { action: 'pack', amount: 0, reason: 'Folding weak hand' };
      }
    }
  }

  // 3. Multi-player or continued betting:
  // Hand assessment:
  // High Card:
  if (rankType === HandRankType.HIGH_CARD) {
    const highRank = bot.cards.map((c) => c.rank).sort((a, b) => b - a)[0];

    // Bluffers might still bet
    if (bot.personality === 'bluffer' && Math.random() < 0.4) {
      return { action: 'chaal_bet', amount: minChaal, reason: 'Bluffing' };
    }

    // If Ace high and conservative, 30% call, otherwise pack
    if (highRank === 14 && Math.random() < 0.35) {
      return { action: 'chaal_bet', amount: minChaal, reason: 'Ace high float' };
    }

    // Most players fold high card when facing action
    return { action: 'pack', amount: 0, reason: 'High card fold' };
  }

  // Pair:
  if (rankType === HandRankType.PAIR) {
    const pairRank = hand.tieBreakers[0];
    // High pairs (10 and above): confident call or raise
    if (pairRank >= 10) {
      if (bot.chips >= minChaal * 2 && Math.random() < 0.35) {
        return { action: 'chaal_raise', amount: minChaal * 2, reason: 'Strong pair raise' };
      }
      return { action: 'chaal_bet', amount: minChaal, reason: 'Solid pair bet' };
    }

    // Low pair: call unless tight personality with heavy pot
    if (bot.personality === 'tight' && minChaal > potTotal * 0.4 && Math.random() < 0.3) {
      return { action: 'pack', amount: 0, reason: 'Folding small pair' };
    }
    return { action: 'chaal_bet', amount: minChaal, reason: 'Playing small pair' };
  }

  // Color (Flush), Sequence, Pure Sequence, Trail:
  // Strong hands!
  if (rankType >= HandRankType.COLOR) {
    const canRaise = bot.chips >= minChaal * 2;
    const shouldRaise = 
      rankType >= HandRankType.SEQUENCE ? Math.random() < 0.6 : Math.random() < 0.35;

    if (canRaise && shouldRaise) {
      return { action: 'chaal_raise', amount: minChaal * 2, reason: 'Raising strong hand' };
    }
    return { action: 'chaal_bet', amount: minChaal, reason: 'Playing strong hand' };
  }

  return { action: 'chaal_bet', amount: minChaal, reason: 'Standard Chaal' };
}
