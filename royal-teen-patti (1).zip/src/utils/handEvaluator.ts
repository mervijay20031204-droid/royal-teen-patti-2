import { Card, HandEvaluation, HandRankType, Rank } from '../types/game';
import { getRankLabel } from './deck';

/**
 * Checks if 3 ranks form a sequence in Teen Patti.
 * Note in Teen Patti:
 * 1. A-K-Q (14, 13, 12) is the highest sequence.
 * 2. A-2-3 (14, 2, 3) is the SECOND highest sequence!
 * 3. K-Q-J (13, 12, 11), Q-J-10, ..., 4-3-2 is lowest.
 */
function getSequenceScore(ranks: Rank[]): { isSeq: boolean; seqScore: number; displayOrder: string } {
  // ranks is sorted descending
  const [r1, r2, r3] = ranks;

  // Check A-K-Q
  if (r1 === 14 && r2 === 13 && r3 === 12) {
    return { isSeq: true, seqScore: 1400, displayOrder: 'A-K-Q' };
  }

  // Check A-2-3 (A is high in ranks array: 14, 3, 2)
  if (r1 === 14 && r2 === 3 && r3 === 2) {
    return { isSeq: true, seqScore: 1350, displayOrder: 'A-2-3' };
  }

  // Standard consecutive descending: r1 = r2 + 1 and r2 = r3 + 1
  if (r1 - r2 === 1 && r2 - r3 === 1) {
    return {
      isSeq: true,
      seqScore: r1 * 100,
      displayOrder: `${getRankLabel(r1)}-${getRankLabel(r2)}-${getRankLabel(r3)}`,
    };
  }

  return { isSeq: false, seqScore: 0, displayOrder: '' };
}

export function evaluateHand(cards: Card[]): HandEvaluation {
  if (!cards || cards.length < 3) {
    return {
      rankType: HandRankType.HIGH_CARD,
      rankName: 'Incomplete',
      score: 0,
      description: 'Waiting for cards',
      tieBreakers: [0, 0, 0],
    };
  }

  // Sort ranks descending
  const sortedRanks = [...cards.map((c) => c.rank)].sort((a, b) => b - a) as Rank[];
  const suits = cards.map((c) => c.suit);
  const isFlush = suits[0] === suits[1] && suits[1] === suits[2];

  const [r1, r2, r3] = sortedRanks;
  const seqInfo = getSequenceScore(sortedRanks);

  // 1. Trail (Three of a Kind / Set)
  if (r1 === r2 && r2 === r3) {
    return {
      rankType: HandRankType.TRAIL,
      rankName: 'Trail (Trio)',
      score: 600000 + r1 * 1000,
      description: `Three of a Kind (${getRankLabel(r1)}s)`,
      tieBreakers: [r1, r1, r1],
    };
  }

  // 2. Pure Sequence (Straight Flush)
  if (isFlush && seqInfo.isSeq) {
    return {
      rankType: HandRankType.PURE_SEQUENCE,
      rankName: 'Pure Sequence',
      score: 500000 + seqInfo.seqScore,
      description: `Pure Sequence (${seqInfo.displayOrder})`,
      tieBreakers: [seqInfo.seqScore, r1, r2],
    };
  }

  // 3. Sequence (Straight / Normal Run)
  if (seqInfo.isSeq) {
    return {
      rankType: HandRankType.SEQUENCE,
      rankName: 'Sequence (Run)',
      score: 400000 + seqInfo.seqScore,
      description: `Sequence (${seqInfo.displayOrder})`,
      tieBreakers: [seqInfo.seqScore, r1, r2],
    };
  }

  // 4. Color (Flush)
  if (isFlush) {
    return {
      rankType: HandRankType.COLOR,
      rankName: 'Color (Flush)',
      score: 300000 + r1 * 100 + r2 * 10 + r3,
      description: `Flush of ${cards[0].suit} (${getRankLabel(r1)} High)`,
      tieBreakers: [r1, r2, r3],
    };
  }

  // 5. Pair
  if (r1 === r2 || r2 === r3 || r1 === r3) {
    const pairRank = r1 === r2 ? r1 : r2 === r3 ? r2 : r1;
    const kickerRank = r1 === r2 ? r3 : r2 === r3 ? r1 : r2;
    return {
      rankType: HandRankType.PAIR,
      rankName: 'Pair',
      score: 200000 + pairRank * 100 + kickerRank,
      description: `Pair of ${getRankLabel(pairRank)}s (${getRankLabel(kickerRank)} kicker)`,
      tieBreakers: [pairRank, kickerRank, 0],
    };
  }

  // 6. High Card
  return {
    rankType: HandRankType.HIGH_CARD,
    rankName: 'High Card',
    score: 100000 + r1 * 100 + r2 * 10 + r3,
    description: `High Card (${getRankLabel(r1)}-${getRankLabel(r2)}-${getRankLabel(r3)})`,
    tieBreakers: [r1, r2, r3],
  };
}

/**
 * Compare two hands. Returns:
 * > 0 if handA wins
 * < 0 if handB wins
 * 0 if exact tie
 */
export function compareHands(cardsA: Card[], cardsB: Card[]): number {
  const evalA = evaluateHand(cardsA);
  const evalB = evaluateHand(cardsB);

  if (evalA.rankType !== evalB.rankType) {
    return evalA.rankType - evalB.rankType;
  }

  // Same rank type, compare tie breakers
  for (let i = 0; i < evalA.tieBreakers.length; i++) {
    if (evalA.tieBreakers[i] !== evalB.tieBreakers[i]) {
      return evalA.tieBreakers[i] - evalB.tieBreakers[i];
    }
  }

  return 0;
}
