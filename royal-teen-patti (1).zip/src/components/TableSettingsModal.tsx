import React from 'react';
import { TableSettings } from '../types/game';
import { X, Volume2, VolumeX, Sliders, Coins, RotateCcw, Users, Zap } from 'lucide-react';

interface TableSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: TableSettings;
  onUpdateSettings: (newSettings: Partial<TableSettings>) => void;
  onReloadChips: () => void;
  onNewGame: () => void;
}

export const TableSettingsModal: React.FC<TableSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onReloadChips,
  onNewGame,
}) => {
  if (!isOpen) return null;

  const bootOptions = [10, 20, 50, 100, 250];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-amber-500/50 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold font-serif text-amber-200">Table Settings</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Boot Amount Selector */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span>Boot (Ante) Amount</span>
            <span className="text-amber-400 font-mono font-bold">₹{settings.bootAmount}</span>
          </label>
          <div className="grid grid-cols-5 gap-1.5">
            {bootOptions.map((opt) => (
              <button
                key={opt}
                onClick={() => onUpdateSettings({ bootAmount: opt })}
                className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  settings.bootAmount === opt
                    ? 'bg-amber-500 text-slate-950 shadow-md font-mono'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-mono'
                }`}
              >
                ₹{opt}
              </button>
            ))}
          </div>
        </div>

        {/* Opponents Count */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span>Number of Opponents</span>
            <span className="text-amber-400 font-bold">{settings.botCount} Bots</span>
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[2, 3, 4].map((count) => (
              <button
                key={count}
                onClick={() => onUpdateSettings({ botCount: count as 2 | 3 | 4 })}
                className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  settings.botCount === count
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>{count} Bots</span>
              </button>
            ))}
          </div>
        </div>

        {/* Sound Toggle */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-900/80 border border-white/5">
          <div className="flex items-center gap-2.5">
            {settings.soundEnabled ? (
              <Volume2 className="w-5 h-5 text-emerald-400" />
            ) : (
              <VolumeX className="w-5 h-5 text-slate-500" />
            )}
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white">Audio Sound FX</span>
              <span className="text-[11px] text-slate-400">Card flips, chip clicks, victory fanfare</span>
            </div>
          </div>
          <button
            onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.soundEnabled ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
          >
            <span
              className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform ${
                settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Free Chips / Reload */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-amber-950/40 to-yellow-950/40 border border-amber-500/30">
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-400" />
            <div className="flex flex-col">
              <span className="text-xs font-bold text-amber-200">Royal Chip Reload</span>
              <span className="text-[11px] text-slate-400">Add +₹5,000 chips instantly</span>
            </div>
          </div>
          <button
            onClick={() => {
              onReloadChips();
              onClose();
            }}
            className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer"
          >
            Claim +₹5k
          </button>
        </div>

        {/* Restart Table */}
        <button
          onClick={() => {
            onNewGame();
            onClose();
          }}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer border border-white/5"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Reset Table & Start Fresh</span>
        </button>
      </div>
    </div>
  );
};
