import React from 'react';

interface ChipProps {
  amount: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  onClick?: () => void;
  selected?: boolean;
}

export const Chip: React.FC<ChipProps> = ({
  amount,
  size = 'md',
  className = '',
  onClick,
  selected = false,
}) => {
  // Determine color scheme based on denomination
  let bgGradient = 'from-emerald-600 via-emerald-500 to-emerald-700';
  let borderStyle = 'border-emerald-300';
  let rimColor = 'bg-emerald-400';
  let textColor = 'text-white';

  if (amount >= 1000) {
    bgGradient = 'from-amber-500 via-amber-400 to-amber-600';
    borderStyle = 'border-amber-200';
    rimColor = 'bg-amber-300';
    textColor = 'text-amber-950 font-black';
  } else if (amount >= 500) {
    bgGradient = 'from-purple-700 via-purple-600 to-purple-800';
    borderStyle = 'border-purple-300';
    rimColor = 'bg-purple-400';
  } else if (amount >= 100) {
    bgGradient = 'from-red-600 via-red-500 to-red-700';
    borderStyle = 'border-red-300';
    rimColor = 'bg-red-400';
  } else if (amount >= 50) {
    bgGradient = 'from-blue-600 via-blue-500 to-blue-700';
    borderStyle = 'border-blue-300';
    rimColor = 'bg-blue-400';
  } else if (amount >= 20) {
    bgGradient = 'from-emerald-600 via-emerald-500 to-emerald-700';
    borderStyle = 'border-emerald-300';
    rimColor = 'bg-emerald-400';
  } else {
    // 10 or less
    bgGradient = 'from-teal-600 via-teal-500 to-teal-700';
    borderStyle = 'border-teal-300';
    rimColor = 'bg-teal-400';
  }

  const sizeClasses = {
    sm: 'w-7 h-7 text-[10px]',
    md: 'w-10 h-10 text-xs',
    lg: 'w-14 h-14 text-sm',
  }[size];

  return (
    <div
      onClick={onClick}
      className={`relative rounded-full select-none flex items-center justify-center font-bold tracking-tight shadow-md transition-all duration-200 ${sizeClasses} ${
        selected ? 'ring-2 ring-yellow-300 -translate-y-1 scale-110 shadow-yellow-500/40' : ''
      } ${onClick ? 'cursor-pointer hover:scale-105 active:scale-95' : ''} ${className}`}
    >
      {/* Outer Chip Body with Striped Rim */}
      <div
        className={`absolute inset-0 rounded-full bg-gradient-to-tr ${bgGradient} border-2 ${borderStyle} shadow-inner flex items-center justify-center overflow-hidden`}
      >
        {/* Striped Edge Accents */}
        <div className={`absolute top-0 w-1.5 h-1.5 ${rimColor}`} />
        <div className={`absolute bottom-0 w-1.5 h-1.5 ${rimColor}`} />
        <div className={`absolute left-0 w-1.5 h-1.5 ${rimColor}`} />
        <div className={`absolute right-0 w-1.5 h-1.5 ${rimColor}`} />

        {/* Inner Dashed Ring */}
        <div className="w-5/6 h-5/6 rounded-full border border-dashed border-white/60 flex items-center justify-center bg-black/15">
          {/* Core White/Metallic Center */}
          <div className="w-4/5 h-4/5 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center shadow-inner">
            <span className={`${textColor} drop-shadow-sm`}>
              {amount >= 1000 ? `${amount / 1000}k` : amount}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
