import React from 'react';
import { HandRankType, Player } from '../types/game';
import { evaluateHand } from '../utils/handEvaluator';
import { CardView } from './CardView';
import { Eye, ShieldAlert, Award, Bot, User, CheckCircle2 } from 'lucide-react';

interface PlayerSeatProps {
  player: Player;
  isCurrentTurn: boolean;
  isDealer: boolean;
  showdown: boolean;
  onSeeCards?: () => void;
  position: 'bottom' | 'top' | 'left' | 'right';
  isThinking?: boolean;
}

export const PlayerSeat: React.FC<PlayerSeatProps> = ({
  player,
  isCurrentTurn,
  isDealer,
  showdown,
  onSeeCards,
  position,
  isThinking = false,
}) => {
  const isFolded = player.status === 'folded';
  const isOut = player.status === 'out';
  const isHuman = player.isHuman;

  // For human, if isSeen is true, cards are face up. For bots, cards are face up only in showdown or if already folded/eliminated (or face down).
  const areCardsRevealed = showdown ? !isFolded : isHuman ? player.isSeen : false;

  const handEval = areCardsRevealed && player.cards.length === 3 ? evaluateHand(player.cards) : null;

  // Position-specific adjustments
  const isBottom = position === 'bottom';
  const cardSize = isBottom ? 'md' : 'sm';

  return (
    <div
      className={`flex flex-col items-center select-none transition-all duration-300 relative ${
        isFolded ? 'opacity-45 scale-95 grayscale' : isOut ? 'opacity-25' : ''
      }`}
    >
      {/* Dealer Token */}
      {isDealer && (
        <div className="absolute -top-3 -right-3 z-30 w-6 h-6 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-200 border-2 border-amber-600 text-amber-950 font-black text-xs flex items-center justify-center shadow-lg font-serif">
          D
        </div>
      )}

      {/* Floating Action / Speech Bubble */}
      {player.lastAction && (
        <div className="absolute -top-8 z-30 px-3 py-1 rounded-full bg-black/90 border border-amber-400 text-amber-300 text-xs font-bold shadow-lg animate-bounce backdrop-blur-sm whitespace-nowrap">
          {player.lastAction}
        </div>
      )}

      {isThinking && (
        <div className="absolute -top-8 z-30 px-3 py-1 rounded-full bg-blue-950/90 border border-blue-400 text-blue-200 text-xs font-semibold shadow-lg backdrop-blur-sm flex items-center gap-1.5 animate-pulse">
          <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
          <span>Thinking...</span>
        </div>
      )}

      {/* Cards Area */}
      <div className={`relative flex items-center justify-center -space-x-4 sm:-space-x-5 my-1 ${isBottom ? 'z-20' : 'z-10'}`}>
        {player.cards.map((card, idx) => {
          // Slight fanned rotation
          const rotationClass = idx === 0 ? '-rotate-6' : idx === 2 ? 'rotate-6' : 'rotate-0';
          return (
            <div
              key={card.id || idx}
              className={`transform transition-all duration-300 ${rotationClass} hover:z-20`}
            >
              <CardView
                card={card}
                isFaceUp={areCardsRevealed}
                size={cardSize}
                onClick={isHuman && !player.isSeen && !isFolded ? onSeeCards : undefined}
              />
            </div>
          );
        })}

        {/* Human "See Cards" Peek Button Overlay */}
        {isHuman && !player.isSeen && !isFolded && (
          <button
            onClick={onSeeCards}
            className="absolute inset-x-0 bottom-2 mx-auto w-fit px-3 py-1 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-amber-950 font-bold text-xs shadow-lg flex items-center gap-1.5 border border-yellow-200 transition-all hover:scale-105 active:scale-95 cursor-pointer z-30 animate-pulse"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>See Cards</span>
          </button>
        )}
      </div>

      {/* Hand description if revealed */}
      {handEval && (
        <div
          className={`mb-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wide shadow-sm border backdrop-blur-md ${
            handEval.rankType >= HandRankType.SEQUENCE
              ? 'bg-amber-500/20 text-amber-300 border-amber-400/50'
              : 'bg-emerald-500/20 text-emerald-300 border-emerald-400/50'
          }`}
        >
          {handEval.rankName}
        </div>
      )}

      {/* Player Profile & Chips Card */}
      <div
        className={`relative flex items-center gap-2 px-3 py-1.5 rounded-xl border backdrop-blur-md transition-all ${
          isCurrentTurn
            ? 'ring-2 ring-amber-400 bg-amber-950/80 border-amber-400 shadow-lg shadow-amber-500/20 scale-105'
            : 'bg-black/70 border-white/10'
        }`}
      >
        {/* Turn halo indicator */}
        {isCurrentTurn && (
          <span className="absolute -inset-0.5 rounded-xl bg-amber-400 opacity-20 blur-xs animate-pulse" />
        )}

        {/* Avatar */}
        <div className="relative w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-tr from-slate-700 to-slate-900 border border-amber-400/40 flex items-center justify-center text-lg overflow-hidden shadow-inner shrink-0">
          <span>{player.avatar}</span>
          <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-black/60 flex items-center justify-center">
            {isHuman ? (
              <User className="w-2 h-2 text-amber-400" />
            ) : (
              <Bot className="w-2 h-2 text-slate-400" />
            )}
          </div>
        </div>

        {/* Info */}
        <div className="flex flex-col text-left">
          <div className="flex items-center gap-1.5 leading-none">
            <span className="text-xs sm:text-sm font-bold text-white tracking-wide truncate max-w-[80px] sm:max-w-[100px]">
              {player.name}
            </span>
            {isHuman && (
              <span className="text-[10px] text-amber-300 font-semibold">(You)</span>
            )}
          </div>

          <div className="flex items-center gap-1 mt-0.5">
            <span className="text-amber-400 text-xs font-serif font-black">₹</span>
            <span className="text-xs sm:text-sm font-extrabold text-amber-300 font-mono">
              {player.chips.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Status Badge: BLIND / SEEN / PACKED */}
        <div className="ml-1 flex flex-col items-end">
          {isFolded ? (
            <span className="text-[10px] font-bold text-red-400 bg-red-950/80 px-1.5 py-0.5 rounded border border-red-800">
              PACK
            </span>
          ) : player.isSeen ? (
            <span className="text-[10px] font-bold text-emerald-300 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-700/60 flex items-center gap-0.5">
              <CheckCircle2 className="w-2.5 h-2.5" />
              <span>SEEN</span>
            </span>
          ) : (
            <span className="text-[10px] font-bold text-amber-300 bg-amber-950/80 px-1.5 py-0.5 rounded border border-amber-600/60 flex items-center gap-0.5">
              <span>BLIND</span>
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
