import React from 'react';
import { X, Trophy, Flame, HelpCircle } from 'lucide-react';

interface HandRankingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const RANKINGS = [
  {
    tier: 1,
    name: 'Trail (Set / Trio)',
    hindiName: 'त्रिक (तीन एक समान)',
    description: 'Three cards of the exact same rank. AAA is the highest, 222 is the lowest.',
    exampleCards: ['A♠', 'A♥', 'A♦'],
    color: 'from-amber-500 to-yellow-300',
  },
  {
    tier: 2,
    name: 'Pure Sequence (Straight Flush)',
    hindiName: 'प्योर सीक्वेंस',
    description: 'Three consecutive cards of the exact same suit. In Teen Patti, A-K-Q is highest, A-2-3 is second highest, followed by K-Q-J down to 4-3-2.',
    exampleCards: ['A♥', 'K♥', 'Q♥'],
    color: 'from-emerald-500 to-teal-300',
  },
  {
    tier: 3,
    name: 'Sequence (Normal Run)',
    hindiName: 'सीक्वेंस (रन)',
    description: 'Three consecutive cards of mixed suits. Order follows A-K-Q > A-2-3 > K-Q-J > ... > 4-3-2.',
    exampleCards: ['A♠', '2♦', '3♣'],
    color: 'from-blue-500 to-cyan-300',
  },
  {
    tier: 4,
    name: 'Color (Flush)',
    hindiName: 'कलर (फ्लश)',
    description: 'Three cards of the same suit, not in sequence. High card breaks ties.',
    exampleCards: ['K♠', '10♠', '7♠'],
    color: 'from-purple-500 to-pink-300',
  },
  {
    tier: 5,
    name: 'Pair (Double)',
    hindiName: 'जोड़ा (पेयर)',
    description: 'Two cards of the same rank. Higher pair wins; third card (kicker) breaks ties.',
    exampleCards: ['Q♦', 'Q♣', '9♠'],
    color: 'from-rose-500 to-orange-300',
  },
  {
    tier: 6,
    name: 'High Card',
    hindiName: 'हाई कार्ड',
    description: 'No matching combination. Evaluated starting from the highest rank down.',
    exampleCards: ['A♦', 'J♠', '4♥'],
    color: 'from-slate-500 to-slate-400',
  },
];

export const HandRankingsModal: React.FC<HandRankingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-amber-500/50 rounded-3xl p-5 sm:p-6 shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg sm:text-xl font-bold font-serif text-amber-200">
              Teen Patti Hand Rankings
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="overflow-y-auto space-y-3 py-3 pr-1">
          {RANKINGS.map((item) => (
            <div
              key={item.tier}
              className="p-3 rounded-2xl bg-slate-900/60 border border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:border-amber-500/30 transition-all"
            >
              <div className="flex items-start gap-3">
                <div
                  className={`w-7 h-7 rounded-xl bg-gradient-to-tr ${item.color} text-slate-950 font-black text-xs flex items-center justify-center shrink-0 shadow-sm mt-0.5`}
                >
                  #{item.tier}
                </div>
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm sm:text-base text-white">
                      {item.name}
                    </span>
                    <span className="text-[11px] text-amber-400/80 font-medium">
                      {item.hindiName}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Mini cards display */}
              <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center bg-black/40 px-2 py-1 rounded-xl border border-white/5">
                {item.exampleCards.map((c, i) => {
                  const isRed = c.includes('♥') || c.includes('♦');
                  return (
                    <span
                      key={i}
                      className={`text-xs font-bold px-1.5 py-0.5 rounded bg-white text-slate-950 font-mono shadow-xs ${
                        isRed ? 'text-red-600' : 'text-slate-900'
                      }`}
                    >
                      {c}
                    </span>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Quick Rules Summary */}
          <div className="p-3 rounded-2xl bg-amber-950/30 border border-amber-500/20 text-xs text-amber-200/90 space-y-1">
            <div className="font-bold text-amber-300 flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Betting Rules Quick Reference</span>
            </div>
            <p>• <strong>Blind Player:</strong> Bets 1x or 2x the current stake without seeing cards.</p>
            <p>• <strong>Seen Player (Chaal):</strong> Must bet 2x (or 4x raise) what a blind player bets.</p>
            <p>• <strong>Show:</strong> Can only be asked when exactly 2 players remain in the round.</p>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 shrink-0 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-amber-950 font-bold text-sm transition-all cursor-pointer"
          >
            Got It, Back to Game
          </button>
        </div>
      </div>
    </div>
  );
};
