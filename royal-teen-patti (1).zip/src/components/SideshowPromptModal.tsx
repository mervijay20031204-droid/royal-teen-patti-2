import React from 'react';
import { Player } from '../types/game';
import { Award, Check, X } from 'lucide-react';

interface SideshowPromptModalProps {
  requester: Player;
  target: Player;
  cost: number;
  onAccept: () => void;
  onDecline: () => void;
}

export const SideshowPromptModal: React.FC<SideshowPromptModalProps> = ({
  requester,
  cost,
  onAccept,
  onDecline,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 to-black border-2 border-indigo-500/80 rounded-2xl p-5 shadow-2xl text-center flex flex-col items-center gap-3">
        <div className="w-12 h-12 rounded-full bg-indigo-950 border border-indigo-400 flex items-center justify-center text-indigo-300">
          <Award className="w-6 h-6 animate-pulse" />
        </div>

        <h3 className="text-lg font-bold text-white">Sideshow Requested!</h3>
        <p className="text-xs text-slate-300">
          <strong className="text-amber-300">{requester.name}</strong> wants to compare cards with you for ₹{cost}. The player with the lower hand must pack!
        </p>

        <div className="grid grid-cols-2 gap-2 w-full mt-2">
          <button
            onClick={onDecline}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <X className="w-4 h-4 text-red-400" />
            <span>Decline</span>
          </button>
          <button
            onClick={onAccept}
            className="py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer"
          >
            <Check className="w-4 h-4 text-green-300" />
            <span>Accept Sideshow</span>
          </button>
        </div>
      </div>
    </div>
  );
};
