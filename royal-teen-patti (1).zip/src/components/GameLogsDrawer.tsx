import React from 'react';
import { GameLog } from '../types/game';
import { ScrollText, X } from 'lucide-react';

interface GameLogsDrawerProps {
  logs: GameLog[];
  isOpen: boolean;
  onClose: () => void;
}

export const GameLogsDrawer: React.FC<GameLogsDrawerProps> = ({
  logs,
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-sm bg-slate-950/95 border-l border-amber-500/30 backdrop-blur-xl shadow-2xl p-4 flex flex-col animate-in slide-in-from-right duration-300">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2">
          <ScrollText className="w-5 h-5 text-amber-400" />
          <h3 className="text-base font-bold text-white font-serif">Table Activity Log</h3>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Logs Feed */}
      <div className="flex-1 overflow-y-auto py-3 space-y-2 pr-1 text-xs">
        {logs.length === 0 ? (
          <div className="text-slate-500 text-center py-8">No actions recorded yet.</div>
        ) : (
          logs.map((log) => {
            const badgeColor =
              log.type === 'win'
                ? 'text-yellow-400 bg-amber-950/80 border-amber-500/50'
                : log.type === 'fold'
                ? 'text-red-400 bg-red-950/60 border-red-800/40'
                : log.type === 'see'
                ? 'text-blue-300 bg-blue-950/60 border-blue-800/40'
                : 'text-emerald-300 bg-emerald-950/60 border-emerald-800/40';

            return (
              <div
                key={log.id}
                className="p-2.5 rounded-xl bg-slate-900/60 border border-white/5 flex items-start justify-between gap-2"
              >
                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-white">{log.playerName}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded border font-semibold ${badgeColor}`}
                    >
                      {log.action}
                    </span>
                  </div>
                  {log.amount && (
                    <span className="text-[11px] text-amber-300 font-mono mt-0.5">
                      Amount: ₹{log.amount}
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-slate-500 font-mono shrink-0">
                  {log.timestamp}
                </span>
              </div>
            );
          })
        )}
      </div>

      {/* Footer */}
      <div className="pt-2 border-t border-white/10 shrink-0 text-center text-[11px] text-slate-400">
        Live Round Play-by-Play
      </div>
    </div>
  );
};
