import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Player } from '../types/game';
import { evaluateHand } from '../utils/handEvaluator';
import { CardView } from './CardView';
import { Crown, Sparkles, Trophy, ArrowRight, RotateCcw } from 'lucide-react';

interface ShowdownModalProps {
  winner: Player;
  potWon: number;
  players: Player[];
  onNextRound: () => void;
  reason?: string;
}

export const ShowdownModal: React.FC<ShowdownModalProps> = ({
  winner,
  potWon,
  players,
  onNextRound,
  reason,
}) => {
  const isHumanWinner = winner.isHuman;

  useEffect(() => {
    // Fire confetti for celebration
    try {
      confetti({
        particleCount: isHumanWinner ? 90 : 45,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#f59e0b', '#10b981', '#ec4899', '#3b82f6', '#fbbf24'],
      });
    } catch {
      // Ignore
    }
  }, [isHumanWinner]);

  // Sort players so winner is first, followed by other active players, then folded players
  const sortedPlayers = [...players].sort((a, b) => {
    if (a.id === winner.id) return -1;
    if (b.id === winner.id) return 1;
    if (a.status !== 'folded' && b.status === 'folded') return -1;
    if (a.status === 'folded' && b.status !== 'folded') return 1;
    return 0;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-slate-900 via-slate-950 to-black border-2 border-amber-500/70 rounded-3xl p-5 sm:p-6 shadow-2xl overflow-hidden flex flex-col items-center text-center">
        {/* Decorative Top Flare */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent" />
        <div className="absolute -top-16 w-48 h-48 rounded-full bg-amber-500/20 blur-2xl pointer-events-none" />

        {/* Winner Crown & Trophy Icon */}
        <div className="relative mb-2">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 border-2 border-yellow-200 flex items-center justify-center shadow-xl shadow-amber-500/30">
            {isHumanWinner ? (
              <Trophy className="w-9 h-9 sm:w-11 sm:h-11 text-amber-950 animate-bounce" />
            ) : (
              <Crown className="w-9 h-9 sm:w-11 sm:h-11 text-amber-950" />
            )}
          </div>
          <div className="absolute -top-2 -right-2 text-2xl animate-pulse">👑</div>
        </div>

        {/* Winner Title */}
        <h2 className="text-2xl sm:text-3xl font-black font-serif text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 tracking-wide">
          {winner.name} Wins!
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-md">
          {reason || `Takes the entire pot with a superior hand!`}
        </p>

        {/* Pot Won Badge */}
        <div className="my-3 px-5 py-2 rounded-2xl bg-amber-950/80 border border-amber-400/60 shadow-inner flex items-center gap-2">
          <span className="text-amber-400 text-xs sm:text-sm font-semibold uppercase tracking-wider">Pot Won:</span>
          <span className="text-xl sm:text-2xl font-black font-mono text-yellow-300">
            ₹{potWon.toLocaleString()}
          </span>
          <Sparkles className="w-4 h-4 text-yellow-400" />
        </div>

        {/* Showdown Hands Comparison Grid */}
        <div className="w-full my-3 space-y-2 max-h-56 overflow-y-auto pr-1">
          {sortedPlayers.map((player) => {
            const isRoundWinner = player.id === winner.id;
            const isFolded = player.status === 'folded';
            const handEval = !isFolded && player.cards.length === 3 ? evaluateHand(player.cards) : null;

            return (
              <div
                key={player.id}
                className={`flex items-center justify-between p-2 sm:p-2.5 rounded-xl border transition-all ${
                  isRoundWinner
                    ? 'bg-amber-950/60 border-amber-400/80 shadow-md ring-1 ring-amber-400/50'
                    : isFolded
                    ? 'bg-black/30 border-white/5 opacity-50'
                    : 'bg-slate-900/60 border-slate-700/60'
                }`}
              >
                {/* Player details */}
                <div className="flex items-center gap-2 text-left">
                  <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-sm shrink-0">
                    {player.avatar}
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1">
                      <span className="text-xs sm:text-sm font-bold text-white">
                        {player.name}
                      </span>
                      {isRoundWinner && (
                        <span className="text-[10px] font-bold text-amber-300 px-1 rounded bg-amber-900/80 border border-amber-500/50">
                          WINNER
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 font-medium">
                      {isFolded ? 'Packed' : handEval ? handEval.rankName : '—'}
                    </span>
                  </div>
                </div>

                {/* Hand Cards */}
                <div className="flex items-center -space-x-3">
                  {player.cards.map((card, idx) => (
                    <CardView
                      key={card.id || idx}
                      card={card}
                      isFaceUp={!isFolded}
                      size="sm"
                      isHighlighted={isRoundWinner}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Button: Next Round */}
        <button
          onClick={onNextRound}
          className="mt-3 w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-amber-950 font-black text-sm sm:text-base tracking-wider uppercase font-serif shadow-xl shadow-amber-500/30 flex items-center justify-center gap-2 border border-yellow-200 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
        >
          <span>Deal Next Round</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
