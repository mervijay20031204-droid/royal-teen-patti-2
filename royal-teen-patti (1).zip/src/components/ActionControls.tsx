import React, { useState } from 'react';
import { Player } from '../types/game';
import { Eye, EyeOff, XCircle, Award, TrendingUp, Sparkles, Coins } from 'lucide-react';

interface ActionControlsProps {
  player: Player;
  isMyTurn: boolean;
  currentStake: number;
  activePlayersCount: number;
  onBet: (amount: number, isRaise: boolean) => void;
  onPack: () => void;
  onShow: () => void;
  onSeeCards: () => void;
  onSideshow?: () => void;
  canSideshow?: boolean;
}

export const ActionControls: React.FC<ActionControlsProps> = ({
  player,
  isMyTurn,
  currentStake,
  activePlayersCount,
  onBet,
  onPack,
  onShow,
  onSeeCards,
  onSideshow,
  canSideshow = false,
}) => {
  const isBlind = !player.isSeen;
  const isFolded = player.status === 'folded';

  // Base requirement:
  // For Blind player: base bet = currentStake
  // For Seen player: base bet = currentStake * 2
  const baseBet = isBlind ? currentStake : currentStake * 2;
  const raiseBet = baseBet * 2;

  const [betMultiplier, setBetMultiplier] = useState<1 | 2>(1);

  const selectedBet = betMultiplier === 1 ? baseBet : raiseBet;
  const canAffordSelected = player.chips >= selectedBet;
  const canAffordShow = player.chips >= baseBet;
  const isShowEligible = activePlayersCount === 2;

  if (isFolded) {
    return (
      <div className="w-full max-w-2xl mx-auto px-4 py-3 bg-black/60 backdrop-blur-md rounded-2xl border border-white/10 text-center text-slate-400 text-sm">
        You folded this round. Enjoy watching the remaining players battle for the pot!
      </div>
    );
  }

  return (
    <div className="w-full max-w-3xl mx-auto px-2 sm:px-4 py-2 sm:py-3 bg-gradient-to-t from-black via-slate-950/95 to-slate-900/90 backdrop-blur-xl rounded-2xl border border-amber-500/30 shadow-2xl flex flex-col gap-2.5">
      {/* Top Helper row: Blind/Seen toggle status & Bet sizing chips */}
      <div className="flex items-center justify-between gap-2 px-1">
        {/* Blind / Seen Status Indicator */}
        <div className="flex items-center gap-2">
          {isBlind ? (
            <button
              onClick={onSeeCards}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-white text-xs font-bold shadow-md cursor-pointer border border-amber-300 transition-all hover:scale-105 active:scale-95"
            >
              <Eye className="w-3.5 h-3.5 text-yellow-200" />
              <span>See Cards (Chaal 2x)</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-600 text-emerald-300 text-xs font-semibold">
              <EyeOff className="w-3.5 h-3.5 text-emerald-400" />
              <span>Playing SEEN</span>
            </div>
          )}

          <div className="text-xs text-slate-300 hidden sm:flex items-center gap-1">
            <span>Your chips:</span>
            <strong className="text-amber-400 font-mono">₹{player.chips.toLocaleString()}</strong>
          </div>
        </div>

        {/* Stake Multiplier (Normal 1x or Raise 2x) */}
        {isMyTurn && (
          <div className="flex items-center gap-1.5 bg-black/60 p-1 rounded-xl border border-white/10">
            <span className="text-[11px] text-slate-400 px-1 font-medium">Bet:</span>
            <button
              onClick={() => setBetMultiplier(1)}
              className={`px-2.5 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                betMultiplier === 1
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {baseBet} (1x)
            </button>
            <button
              onClick={() => setBetMultiplier(2)}
              disabled={player.chips < raiseBet}
              className={`px-2.5 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                betMultiplier === 2
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed'
              }`}
            >
              <span className="flex items-center gap-0.5">
                <TrendingUp className="w-3 h-3 inline" />
                <span>{raiseBet} (2x)</span>
              </span>
            </button>
          </div>
        )}
      </div>

      {/* Main Action Buttons Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
        {/* 1. PACK (FOLD) */}
        <button
          onClick={onPack}
          disabled={!isMyTurn}
          className={`group flex items-center justify-center gap-1.5 py-2.5 sm:py-3 px-3 rounded-xl border font-bold text-xs sm:text-sm tracking-wide transition-all shadow-md cursor-pointer ${
            isMyTurn
              ? 'bg-gradient-to-b from-red-950 via-red-900 to-red-950 hover:from-red-900 hover:to-red-800 border-red-700/80 text-red-200 hover:text-white hover:scale-[1.02] active:scale-[0.98]'
              : 'bg-slate-900/50 border-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          <XCircle className="w-4 h-4 text-red-400 group-hover:rotate-90 transition-transform" />
          <span>PACK</span>
        </button>

        {/* 2. SIDESHOW (If available) or SHOW (when 2 players remain) */}
        {isShowEligible ? (
          <button
            onClick={onShow}
            disabled={!isMyTurn || !canAffordShow}
            className={`col-span-1 flex items-center justify-center gap-1.5 py-2.5 sm:py-3 px-3 rounded-xl border font-black text-xs sm:text-sm tracking-wide transition-all shadow-lg cursor-pointer ${
              isMyTurn && canAffordShow
                ? 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 border-yellow-200 text-amber-950 shadow-amber-500/30 animate-pulse hover:scale-[1.02] active:scale-[0.98]'
                : 'bg-slate-900/50 border-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-900" />
            <div className="flex flex-col items-center leading-tight">
              <span>SHOW</span>
              <span className="text-[10px] font-mono font-bold opacity-80">(₹{baseBet})</span>
            </div>
          </button>
        ) : canSideshow && onSideshow ? (
          <button
            onClick={onSideshow}
            disabled={!isMyTurn || !canAffordShow}
            className={`col-span-1 flex items-center justify-center gap-1.5 py-2.5 sm:py-3 px-3 rounded-xl border font-bold text-xs sm:text-sm tracking-wide transition-all shadow-md cursor-pointer ${
              isMyTurn && canAffordShow
                ? 'bg-gradient-to-b from-indigo-900 to-indigo-950 hover:from-indigo-800 hover:to-indigo-900 border-indigo-500 text-indigo-200 hover:text-white hover:scale-[1.02] active:scale-[0.98]'
                : 'bg-slate-900/50 border-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Award className="w-4 h-4 text-indigo-400" />
            <div className="flex flex-col items-center leading-tight">
              <span>SIDESHOW</span>
              <span className="text-[10px] font-mono">(₹{baseBet})</span>
            </div>
          </button>
        ) : (
          <div className="hidden sm:flex flex-col items-center justify-center p-2 rounded-xl bg-black/30 border border-white/5 text-slate-500 text-[11px] text-center leading-tight">
            <span>Show unlocks at</span>
            <span className="font-semibold text-slate-400">2 Players Left</span>
          </div>
        )}

        {/* 3. PRIMARY BET: BLIND or CHAAL */}
        <button
          onClick={() => onBet(selectedBet, betMultiplier === 2)}
          disabled={!isMyTurn || !canAffordSelected}
          className={`col-span-2 flex items-center justify-center gap-2 py-2.5 sm:py-3 px-4 rounded-xl border font-black text-sm sm:text-base tracking-wide transition-all shadow-xl cursor-pointer ${
            isMyTurn && canAffordSelected
              ? isBlind
                ? 'bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 border-amber-300 text-amber-950 shadow-amber-500/25 hover:scale-[1.02] active:scale-[0.98]'
                : 'bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 hover:from-emerald-500 hover:to-teal-400 border-emerald-300 text-emerald-950 shadow-emerald-500/25 hover:scale-[1.02] active:scale-[0.98]'
              : 'bg-slate-900/60 border-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          <Coins className="w-5 h-5 text-current shrink-0" />
          <div className="flex items-center gap-1.5 leading-none">
            <span>{isBlind ? 'BLIND' : 'CHAAL'}</span>
            <span className="text-xs sm:text-sm font-mono opacity-90 px-1.5 py-0.5 rounded-md bg-black/20">
              ₹{selectedBet}
            </span>
            {betMultiplier === 2 && (
              <span className="text-[10px] uppercase font-bold tracking-wider px-1 rounded bg-black/20 text-white">
                Raise
              </span>
            )}
          </div>
        </button>
      </div>
    </div>
  );
};
