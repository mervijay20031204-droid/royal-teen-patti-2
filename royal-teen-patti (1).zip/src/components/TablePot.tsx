import React from 'react';
import { Chip } from './Chip';
import { Coins, Flame } from 'lucide-react';

interface TablePotProps {
  potTotal: number;
  currentStake: number;
  roundNumber: number;
  dealerIndex: number;
  activePlayersCount: number;
}

export const TablePot: React.FC<TablePotProps> = ({
  potTotal,
  currentStake,
  roundNumber,
  activePlayersCount,
}) => {
  return (
    <div className="relative flex flex-col items-center justify-center pointer-events-none select-none my-2 sm:my-4">
      {/* Decorative Felt Mandala Ring */}
      <div className="absolute w-44 h-44 sm:w-60 sm:h-60 rounded-full border border-amber-400/20 bg-amber-500/5 -z-10 flex items-center justify-center animate-pulse">
        <div className="w-36 h-36 sm:w-48 sm:h-48 rounded-full border border-dashed border-amber-300/20" />
      </div>

      {/* Chip Stack representation in center */}
      <div className="relative flex items-center justify-center h-14 w-28 mb-1">
        {potTotal > 0 && (
          <div className="flex -space-x-4 items-center">
            <div className="transform -rotate-12 translate-y-1">
              <Chip amount={Math.min(currentStake, 50)} size="sm" />
            </div>
            <div className="transform rotate-3 -translate-y-1 z-10">
              <Chip amount={Math.min(Math.floor(potTotal / 4), 100)} size="md" />
            </div>
            <div className="transform rotate-12 translate-y-0.5">
              <Chip amount={Math.min(currentStake * 2, 500)} size="sm" />
            </div>
          </div>
        )}
      </div>

      {/* Pot Banner */}
      <div className="relative px-5 py-2 rounded-2xl bg-gradient-to-r from-amber-950/90 via-black/85 to-amber-950/90 border border-amber-400/60 shadow-xl backdrop-blur-md flex flex-col items-center">
        <div className="flex items-center gap-1.5 text-amber-300 text-xs sm:text-sm font-semibold tracking-wider uppercase font-serif">
          <Coins className="w-4 h-4 text-amber-400 animate-bounce" />
          <span>Total Pot</span>
        </div>
        <div className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-100 via-amber-300 to-amber-500 font-serif tracking-wide drop-shadow-md">
          {potTotal.toLocaleString()}
        </div>
      </div>

      {/* Stake & Rule Badges */}
      <div className="flex items-center gap-2 mt-2">
        <div className="bg-black/60 backdrop-blur-sm border border-emerald-500/40 text-emerald-300 text-[11px] sm:text-xs px-2.5 py-0.5 rounded-full flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <span>Stake: <strong className="text-white font-mono">{currentStake}</strong></span>
          <span className="text-emerald-500/70">|</span>
          <span>Chaal: <strong className="text-amber-300 font-mono">{currentStake * 2}</strong></span>
        </div>

        {activePlayersCount === 2 && (
          <div className="bg-gradient-to-r from-amber-600 to-orange-600 border border-amber-300 text-white font-bold text-[10px] sm:text-xs px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm animate-pulse">
            <Flame className="w-3 h-3 text-yellow-200" />
            <span>Showdown Available!</span>
          </div>
        )}
      </div>
    </div>
  );
};
