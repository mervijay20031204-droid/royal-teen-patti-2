import React from 'react';
import { Card } from '../types/game';
import { getRankLabel, getSuitColor, getSuitSymbol } from '../utils/deck';

interface CardViewProps {
  card?: Card;
  isFaceUp: boolean;
  size?: 'sm' | 'md' | 'lg';
  isHighlighted?: boolean;
  onClick?: () => void;
  className?: string;
}

export const CardView: React.FC<CardViewProps> = ({
  card,
  isFaceUp,
  size = 'md',
  isHighlighted = false,
  onClick,
  className = '',
}) => {
  const sizeClasses = {
    sm: 'w-12 h-17 text-xs rounded-md shadow-sm',
    md: 'w-16 h-24 sm:w-20 sm:h-28 text-sm rounded-lg shadow-md',
    lg: 'w-20 h-30 sm:w-24 sm:h-36 text-base rounded-xl shadow-lg',
  }[size];

  if (!isFaceUp || !card) {
    // Face-down card design with authentic luxury gold/ruby mandala pattern
    return (
      <div
        onClick={onClick}
        className={`relative select-none border border-amber-500/40 bg-gradient-to-br from-red-950 via-red-900 to-amber-950 flex flex-col items-center justify-center overflow-hidden transition-transform duration-300 ${sizeClasses} ${
          isHighlighted ? 'ring-2 ring-amber-400 scale-105' : ''
        } ${onClick ? 'cursor-pointer hover:-translate-y-1' : ''} ${className}`}
      >
        {/* Subtle patterned overlay */}
        <div className="absolute inset-1 border border-amber-400/30 rounded flex items-center justify-center">
          <div className="w-full h-full opacity-30 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:6px_6px]" />
          <div className="absolute w-6 h-6 sm:w-8 sm:h-8 rounded-full border border-amber-400/50 flex items-center justify-center bg-red-950/60 shadow-inner">
            <span className="text-amber-400 text-[10px] sm:text-xs font-serif font-black">♠♥</span>
          </div>
        </div>
      </div>
    );
  }

  const suitSymbol = getSuitSymbol(card.suit);
  const suitColor = getSuitColor(card.suit);
  const rankLabel = getRankLabel(card.rank);

  return (
    <div
      onClick={onClick}
      className={`relative select-none bg-gradient-to-b from-white via-slate-50 to-slate-100 border border-slate-300/80 flex flex-col justify-between p-1.5 sm:p-2 overflow-hidden transition-transform duration-300 font-sans ${sizeClasses} ${
        isHighlighted ? 'ring-2 ring-amber-400 scale-105 shadow-amber-400/30 shadow-lg' : ''
      } ${onClick ? 'cursor-pointer hover:-translate-y-1' : ''} ${className}`}
    >
      {/* Top Left Rank & Suit */}
      <div className={`flex flex-col items-center leading-none ${suitColor} font-bold`}>
        <span className="text-xs sm:text-sm font-black tracking-tighter">{rankLabel}</span>
        <span className="text-xs sm:text-sm">{suitSymbol}</span>
      </div>

      {/* Center Suit Art */}
      <div className={`absolute inset-0 flex items-center justify-center pointer-events-none ${suitColor}`}>
        {card.rank >= 11 && card.rank <= 13 ? (
          <div className="opacity-90 flex flex-col items-center">
            <span className="text-xl sm:text-2xl font-serif font-black">{rankLabel}</span>
            <span className="text-xs sm:text-sm opacity-70">{suitSymbol}</span>
          </div>
        ) : (
          <span className="text-2xl sm:text-3xl opacity-85">{suitSymbol}</span>
        )}
      </div>

      {/* Bottom Right Inverted Rank & Suit */}
      <div className={`flex flex-col items-center leading-none rotate-180 self-end ${suitColor} font-bold`}>
        <span className="text-xs sm:text-sm font-black tracking-tighter">{rankLabel}</span>
        <span className="text-xs sm:text-sm">{suitSymbol}</span>
      </div>
    </div>
  );
};
