/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Card, GameLog, HandRankType, Player, TableSettings } from './types/game';
import { createDeck, shuffleDeck } from './utils/deck';
import { compareHands, evaluateHand } from './utils/handEvaluator';
import { getAIDecision } from './utils/ai';
import { sounds } from './utils/audio';
import { PlayerSeat } from './components/PlayerSeat';
import { TablePot } from './components/TablePot';
import { ActionControls } from './components/ActionControls';
import { ShowdownModal } from './components/ShowdownModal';
import { HandRankingsModal } from './components/HandRankingsModal';
import { TableSettingsModal } from './components/TableSettingsModal';
import { GameLogsDrawer } from './components/GameLogsDrawer';
import { SideshowPromptModal } from './components/SideshowPromptModal';
import {
  Volume2,
  VolumeX,
  HelpCircle,
  Settings,
  ScrollText,
  RotateCcw,
  Sparkles,
  Coins,
  Shield,
  Layers,
} from 'lucide-react';

const INITIAL_BOTS: Omit<Player, 'chips' | 'cards' | 'isSeen' | 'status' | 'currentBet'>[] = [
  { id: 'bot-1', name: 'Vikram', avatar: '🐯', isHuman: false, personality: 'aggressive' },
  { id: 'bot-2', name: 'Priya', avatar: '🦚', isHuman: false, personality: 'balanced' },
  { id: 'bot-3', name: 'Kabir', avatar: '🎲', isHuman: false, personality: 'bluffer' },
  { id: 'bot-4', name: 'Ananya', avatar: '🦊', isHuman: false, personality: 'tight' },
];

export default function App() {
  // Table Configuration & Settings
  const [settings, setSettings] = useState<TableSettings>({
    bootAmount: 20,
    maxStake: 1024,
    botCount: 3,
    soundEnabled: true,
    gameSpeed: 'normal',
  });

  // Sound sync
  useEffect(() => {
    sounds.enabled = settings.soundEnabled;
  }, [settings.soundEnabled]);

  // Players State
  const [players, setPlayers] = useState<Player[]>([
    {
      id: 'human',
      name: 'You',
      avatar: '👑',
      isHuman: true,
      chips: 5000,
      currentBet: 0,
      cards: [],
      isSeen: false,
      status: 'active',
    },
    ...INITIAL_BOTS.slice(0, 3).map((b) => ({
      ...b,
      chips: 5000,
      currentBet: 0,
      cards: [],
      isSeen: false,
      status: 'active' as const,
    })),
  ]);

  // Table State
  const [potTotal, setPotTotal] = useState<number>(0);
  const [currentStake, setCurrentStake] = useState<number>(20);
  const [dealerIndex, setDealerIndex] = useState<number>(0);
  const [currentTurnIndex, setCurrentTurnIndex] = useState<number>(1);
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [isBotThinking, setIsBotThinking] = useState<boolean>(false);
  const [phase, setPhase] = useState<'idle' | 'betting' | 'showdown' | 'round_ended'>('idle');

  // Modals & Drawers
  const [isRankingsOpen, setIsRankingsOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isLogsOpen, setIsLogsOpen] = useState<boolean>(false);
  const [logs, setLogs] = useState<GameLog[]>([]);

  // Showdown Results
  const [showdownData, setShowdownData] = useState<{
    winner: Player;
    potWon: number;
    reason?: string;
  } | null>(null);

  // Sideshow state
  const [sideshowData, setSideshowData] = useState<{
    requester: Player;
    target: Player;
    cost: number;
  } | null>(null);

  const activePlayers = players.filter((p) => p.status === 'active');
  const activePlayersCount = activePlayers.length;
  const humanPlayer = players.find((p) => p.isHuman) || players[0];
  const isHumanTurn =
    phase === 'betting' && players[currentTurnIndex]?.isHuman && !isBotThinking;

  // Logging helper
  const addLog = useCallback(
    (playerName: string, action: string, amount?: number, type: GameLog['type'] = 'bet') => {
      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now
        .getMinutes()
        .toString()
        .padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;

      setLogs((prev) => [
        {
          id: Math.random().toString(36).substring(2, 9),
          timestamp: timeStr,
          playerName,
          action,
          amount,
          type,
        },
        ...prev.slice(0, 49),
      ]);
    },
    []
  );

  // 1. Start a New Round
  const startNewRound = useCallback(() => {
    setShowdownData(null);
    setSideshowData(null);

    // Filter available bots by current settings
    const activeBots = INITIAL_BOTS.slice(0, settings.botCount);
    
    // Ensure all players have chips (if broke, refill minimally)
    setPlayers((prev) => {
      const existingHuman = prev.find((p) => p.isHuman);
      const humanChips = (existingHuman?.chips || 0) < settings.bootAmount ? 2000 : existingHuman!.chips;

      const newPlayers: Player[] = [
        {
          id: 'human',
          name: 'You',
          avatar: '👑',
          isHuman: true,
          chips: humanChips,
          currentBet: 0,
          cards: [],
          isSeen: false,
          status: 'active',
        },
        ...activeBots.map((b) => {
          const oldBot = prev.find((p) => p.id === b.id);
          const botChips = (oldBot?.chips || 0) < settings.bootAmount ? 2000 : oldBot!.chips;
          return {
            ...b,
            chips: botChips,
            currentBet: 0,
            cards: [],
            isSeen: false,
            status: 'active' as const,
          };
        }),
      ];

      // Shuffle deck and deal 3 cards each
      let deck = shuffleDeck(createDeck());
      const boot = settings.bootAmount;
      let totalBoot = 0;

      const dealtPlayers = newPlayers.map((player) => {
        const hand = deck.slice(0, 3);
        deck = deck.slice(3);
        totalBoot += boot;
        return {
          ...player,
          chips: player.chips - boot,
          currentBet: boot,
          cards: hand,
          isSeen: false,
          status: 'active' as const,
          lastAction: `Boot ₹${boot}`,
        };
      });

      setPotTotal(totalBoot);
      setCurrentStake(boot);
      setPhase('betting');

      // Next dealer
      const nextDealer = (dealerIndex + 1) % dealtPlayers.length;
      setDealerIndex(nextDealer);

      // Turn starts with player next to dealer
      const firstTurn = (nextDealer + 1) % dealtPlayers.length;
      setCurrentTurnIndex(firstTurn);

      return dealtPlayers;
    });

    sounds.playCardDeal();
    addLog('Table', `New Round #${roundNumber} started. Boot ₹${settings.bootAmount} placed.`, undefined, 'info');
    setRoundNumber((r) => r + 1);
  }, [dealerIndex, settings.bootAmount, settings.botCount, roundNumber, addLog]);

  // Start initial round on mount
  useEffect(() => {
    startNewRound();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Check for immediate single-winner when other players fold
  const checkForSingleWinner = useCallback(
    (currentPlayers: Player[], currentPot: number) => {
      const active = currentPlayers.filter((p) => p.status === 'active');
      if (active.length === 1) {
        const winner = active[0];
        // Winner collects pot
        setPlayers((prev) =>
          prev.map((p) =>
            p.id === winner.id ? { ...p, chips: p.chips + currentPot, lastAction: 'WINNER 🏆' } : p
          )
        );
        sounds.playWin();
        setShowdownData({
          winner,
          potWon: currentPot,
          reason: 'All other players packed!',
        });
        setPhase('round_ended');
        addLog(winner.name, 'Won the pot (all opponents packed)', currentPot, 'win');
        return true;
      }
      return false;
    },
    [addLog]
  );

  // Advance to next active player
  const advanceTurn = useCallback(
    (currentList: Player[], fromIndex: number) => {
      let nextIndex = (fromIndex + 1) % currentList.length;
      let count = 0;
      while (currentList[nextIndex].status !== 'active' && count < currentList.length) {
        nextIndex = (nextIndex + 1) % currentList.length;
        count++;
      }
      setCurrentTurnIndex(nextIndex);
    },
    []
  );

  // Execute Showdown
  const handleExecuteShowdown = useCallback(
    (remainingPlayers: Player[], caller: Player, cost: number) => {
      setPhase('showdown');
      sounds.playCardFlip();

      // Deduct show cost
      const updatedPot = potTotal + cost;
      setPotTotal(updatedPot);

      const active = remainingPlayers.filter((p) => p.status === 'active');
      let winner = active[0];

      if (active.length > 1) {
        for (let i = 1; i < active.length; i++) {
          const res = compareHands(active[i].cards, winner.cards);
          if (res > 0) {
            winner = active[i];
          }
        }
      }

      const winnerHand = evaluateHand(winner.cards);

      // Award pot to winner
      setPlayers((prev) =>
        prev.map((p) => {
          let updatedChips = p.chips;
          if (p.id === caller.id) {
            updatedChips -= cost;
          }
          if (p.id === winner.id) {
            updatedChips += updatedPot;
          }
          return {
            ...p,
            chips: updatedChips,
            isSeen: true, // Reveal cards
            lastAction: p.id === winner.id ? 'WINNER 🏆' : p.id === caller.id ? 'Called Show' : p.lastAction,
          };
        })
      );

      sounds.playWin();
      setShowdownData({
        winner,
        potWon: updatedPot,
        reason: `Show called by ${caller.name}! ${winner.name} won with ${winnerHand.rankName}.`,
      });
      addLog(winner.name, `Won Showdown with ${winnerHand.rankName}!`, updatedPot, 'win');
    },
    [potTotal, addLog]
  );

  // Human Actions
  const handleHumanSeeCards = () => {
    setPlayers((prev) =>
      prev.map((p) => (p.isHuman ? { ...p, isSeen: true, lastAction: 'Seen Cards' } : p))
    );
    sounds.playCardFlip();
    addLog('You', 'Viewed your cards (Now playing SEEN)', undefined, 'see');
  };

  const handleHumanBet = (amount: number, isRaise: boolean) => {
    if (!isHumanTurn) return;

    sounds.playChipBet();
    const isBlind = !humanPlayer.isSeen;

    // If raised, update table stake
    if (isRaise) {
      const newStake = isBlind ? amount : Math.floor(amount / 2);
      setCurrentStake(newStake);
    }

    const newPot = potTotal + amount;
    setPotTotal(newPot);

    const actionText = isBlind
      ? isRaise
        ? `Blind Raise ₹${amount}`
        : `Blind ₹${amount}`
      : isRaise
      ? `Chaal Raise ₹${amount}`
      : `Chaal ₹${amount}`;

    const updatedPlayers = players.map((p) =>
      p.isHuman
        ? {
            ...p,
            chips: p.chips - amount,
            currentBet: p.currentBet + amount,
            lastAction: actionText,
          }
        : p
    );

    setPlayers(updatedPlayers);
    addLog('You', actionText, amount, 'bet');
    advanceTurn(updatedPlayers, currentTurnIndex);
  };

  const handleHumanPack = () => {
    if (!isHumanTurn) return;

    sounds.playFold();
    const updatedPlayers = players.map((p) =>
      p.isHuman ? { ...p, status: 'folded' as const, lastAction: 'PACKED' } : p
    );
    setPlayers(updatedPlayers);
    addLog('You', 'Packed (Folded)', undefined, 'fold');

    if (!checkForSingleWinner(updatedPlayers, potTotal)) {
      advanceTurn(updatedPlayers, currentTurnIndex);
    }
  };

  const handleHumanShow = () => {
    if (!isHumanTurn || activePlayersCount !== 2) return;
    const cost = humanPlayer.isSeen ? currentStake * 2 : currentStake;
    handleExecuteShowdown(players, humanPlayer, cost);
  };

  // Bot Turn Automation Effect
  useEffect(() => {
    if (phase !== 'betting') return;
    const currentPlayer = players[currentTurnIndex];
    if (!currentPlayer || currentPlayer.isHuman || currentPlayer.status !== 'active') return;

    setIsBotThinking(true);

    const botTimer = setTimeout(() => {
      // Re-fetch current player state
      const bot = players[currentTurnIndex];
      if (!bot || bot.status !== 'active') {
        setIsBotThinking(false);
        return;
      }

      let decision = getAIDecision(
        bot,
        currentStake,
        activePlayersCount,
        roundNumber,
        potTotal
      );

      // If bot chooses to see cards first:
      if (decision.action === 'see_cards') {
        sounds.playCardFlip();
        // Update to Seen
        const seenBot: Player = { ...bot, isSeen: true, lastAction: 'Seen Cards' };
        setPlayers((prev) =>
          prev.map((p) => (p.id === bot.id ? seenBot : p))
        );
        addLog(bot.name, 'Checked their cards (Now SEEN)', undefined, 'see');

        // Immediately evaluate seen decision
        decision = getAIDecision(
          seenBot,
          currentStake,
          activePlayersCount,
          roundNumber,
          potTotal
        );
      }

      // Execute AI decision:
      if (decision.action === 'pack') {
        sounds.playFold();
        const updated = players.map((p) =>
          p.id === bot.id ? { ...p, status: 'folded' as const, lastAction: 'PACKED' } : p
        );
        setPlayers(updated);
        addLog(bot.name, 'Packed (Folded)', undefined, 'fold');
        setIsBotThinking(false);

        if (!checkForSingleWinner(updated, potTotal)) {
          advanceTurn(updated, currentTurnIndex);
        }
      } else if (decision.action === 'show') {
        const cost = bot.isSeen ? currentStake * 2 : currentStake;
        setIsBotThinking(false);
        handleExecuteShowdown(players, bot, cost);
      } else {
        // Bet action (blind_bet, blind_raise, chaal_bet, chaal_raise)
        const amount = Math.min(decision.amount, bot.chips);
        sounds.playChipBet();

        const isRaise = decision.action === 'blind_raise' || decision.action === 'chaal_raise';
        if (isRaise) {
          const newStake = bot.isSeen ? Math.floor(amount / 2) : amount;
          setCurrentStake(newStake);
        }

        const newPot = potTotal + amount;
        setPotTotal(newPot);

        const actionText =
          decision.action === 'blind_raise'
            ? `Blind Raise ₹${amount}`
            : decision.action === 'blind_bet'
            ? `Blind ₹${amount}`
            : decision.action === 'chaal_raise'
            ? `Chaal Raise ₹${amount}`
            : `Chaal ₹${amount}`;

        const updated = players.map((p) =>
          p.id === bot.id
            ? {
                ...p,
                chips: p.chips - amount,
                currentBet: p.currentBet + amount,
                lastAction: actionText,
              }
            : p
        );

        setPlayers(updated);
        addLog(bot.name, actionText, amount, 'bet');
        setIsBotThinking(false);
        advanceTurn(updated, currentTurnIndex);
      }
    }, 1200);

    return () => clearTimeout(botTimer);
  }, [
    currentTurnIndex,
    phase,
    players,
    currentStake,
    activePlayersCount,
    roundNumber,
    potTotal,
    advanceTurn,
    checkForSingleWinner,
    handleExecuteShowdown,
    addLog,
  ]);

  // Chip Reload function
  const handleReloadChips = () => {
    setPlayers((prev) =>
      prev.map((p) => (p.isHuman ? { ...p, chips: p.chips + 5000 } : p))
    );
    sounds.playWin();
    addLog('Bank', 'Claimed Royal Reload: +₹5,000 chips credited!', 5000, 'info');
  };

  // Bot seat positioning helper (Bot 1, Bot 2, Bot 3, Bot 4 around top arc)
  const getSeatPosition = (idx: number, total: number): 'top' | 'left' | 'right' => {
    if (total === 3) {
      return idx === 1 ? 'left' : 'right';
    }
    if (total === 4) {
      if (idx === 1) return 'left';
      if (idx === 2) return 'top';
      return 'right';
    }
    // 5 players total
    if (idx === 1) return 'left';
    if (idx === 2) return 'top';
    if (idx === 3) return 'top';
    return 'right';
  };

  return (
    <div className="relative min-h-screen w-full bg-radial from-slate-900 via-zinc-950 to-black text-slate-100 flex flex-col justify-between overflow-x-hidden select-none font-sans">
      {/* Top Luxury Casino Navigation Bar */}
      <header className="relative z-40 w-full px-3 sm:px-6 py-2.5 sm:py-3 border-b border-amber-500/20 bg-black/60 backdrop-blur-md flex items-center justify-between shadow-lg">
        {/* Logo and Brand */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 border border-amber-200 flex items-center justify-center text-amber-950 font-black shadow-md font-serif text-base sm:text-lg">
            ♠
          </div>
          <div>
            <h1 className="text-base sm:text-xl font-black font-serif tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-400 leading-none">
              ROYAL TEEN PATTI
            </h1>
            <span className="text-[10px] text-amber-500/80 font-semibold tracking-widest uppercase">
              Classic Indian 3-Card Poker
            </span>
          </div>
        </div>

        {/* Center Pill: Player Wallet */}
        <div className="flex items-center gap-2 px-3 sm:px-4 py-1 sm:py-1.5 rounded-full bg-gradient-to-r from-amber-950/80 via-black/80 to-amber-950/80 border border-amber-500/40 shadow-inner">
          <Coins className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="text-xs text-amber-300/80 uppercase font-semibold hidden sm:inline">
            Balance:
          </span>
          <span className="text-sm sm:text-base font-black font-mono text-amber-300">
            ₹{humanPlayer.chips.toLocaleString()}
          </span>
        </div>

        {/* Right utility buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Audio toggle */}
          <button
            onClick={() => setSettings((s) => ({ ...s, soundEnabled: !s.soundEnabled }))}
            title={settings.soundEnabled ? 'Mute Sounds' : 'Unmute Sounds'}
            className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
          >
            {settings.soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>

          {/* Hand Rankings Guide */}
          <button
            onClick={() => setIsRankingsOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Rules</span>
          </button>

          {/* Logs */}
          <button
            onClick={() => setIsLogsOpen(true)}
            title="Activity Log"
            className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
          >
            <ScrollText className="w-4 h-4 text-amber-400" />
          </button>

          {/* Settings */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            title="Table Settings"
            className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
          >
            <Settings className="w-4 h-4 text-slate-300" />
          </button>
        </div>
      </header>

      {/* Main Poker Arena (Felt Table) */}
      <main className="relative flex-1 flex flex-col items-center justify-between p-2 sm:p-4 max-w-6xl mx-auto w-full">
        {/* Royal Casino Felt Table Container */}
        <div className="relative w-full flex-1 flex flex-col justify-between rounded-[40px] sm:rounded-[60px] p-3 sm:p-6 bg-gradient-to-b from-emerald-950 via-emerald-900 to-emerald-950 border-[10px] sm:border-[14px] border-[#3e2723] shadow-[inset_0_0_80px_rgba(0,0,0,0.85),0_20px_50px_rgba(0,0,0,0.9)] overflow-hidden">
          {/* Table Brass Accent Inlay */}
          <div className="absolute inset-1 sm:inset-2 rounded-[32px] sm:rounded-[48px] border-2 border-amber-500/30 pointer-events-none" />

          {/* Center Felt Watermark Mandala */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10">
            <div className="w-96 h-96 rounded-full border-8 border-amber-300/40 flex items-center justify-center">
              <span className="text-8xl font-serif text-amber-200">♠</span>
            </div>
          </div>

          {/* Top Arc: Computer Opponents */}
          <div className="relative z-20 w-full flex items-center justify-around gap-2 pt-1 sm:pt-2">
            {players
              .filter((p) => !p.isHuman)
              .map((bot, index) => {
                const playerIndex = players.findIndex((p) => p.id === bot.id);
                return (
                  <PlayerSeat
                    key={bot.id}
                    player={bot}
                    isCurrentTurn={currentTurnIndex === playerIndex}
                    isDealer={dealerIndex === playerIndex}
                    showdown={phase === 'showdown'}
                    position={getSeatPosition(index + 1, players.length)}
                    isThinking={isBotThinking && currentTurnIndex === playerIndex}
                  />
                );
              })}
          </div>

          {/* Center: Table Pot, Current Stake & Showdown Info */}
          <div className="relative z-10 flex-1 flex items-center justify-center my-2">
            <TablePot
              potTotal={potTotal}
              currentStake={currentStake}
              roundNumber={roundNumber}
              dealerIndex={dealerIndex}
              activePlayersCount={activePlayersCount}
            />
          </div>

          {/* Bottom Center: Human Player Seat */}
          <div className="relative z-20 w-full flex flex-col items-center pb-1">
            <PlayerSeat
              player={humanPlayer}
              isCurrentTurn={isHumanTurn}
              isDealer={dealerIndex === 0}
              showdown={phase === 'showdown'}
              onSeeCards={handleHumanSeeCards}
              position="bottom"
            />
          </div>
        </div>

        {/* Bottom Interactive Command Dock */}
        <div className="w-full mt-2.5 sm:mt-3 z-30">
          {phase === 'round_ended' || phase === 'showdown' ? (
            <div className="w-full max-w-md mx-auto flex items-center justify-center">
              <button
                onClick={startNewRound}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-amber-950 font-black text-sm sm:text-base font-serif tracking-wider uppercase shadow-xl shadow-amber-500/30 flex items-center justify-center gap-2 border border-yellow-200 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
              >
                <RotateCcw className="w-5 h-5" />
                <span>Deal Next Hand (₹{settings.bootAmount} Boot)</span>
              </button>
            </div>
          ) : (
            <ActionControls
              player={humanPlayer}
              isMyTurn={isHumanTurn}
              currentStake={currentStake}
              activePlayersCount={activePlayersCount}
              onBet={handleHumanBet}
              onPack={handleHumanPack}
              onShow={handleHumanShow}
              onSeeCards={handleHumanSeeCards}
            />
          )}
        </div>
      </main>

      {/* Showdown Results Modal */}
      {showdownData && (
        <ShowdownModal
          winner={showdownData.winner}
          potWon={showdownData.potWon}
          players={players}
          onNextRound={startNewRound}
          reason={showdownData.reason}
        />
      )}

      {/* Hand Rankings Reference Guide Modal */}
      <HandRankingsModal
        isOpen={isRankingsOpen}
        onClose={() => setIsRankingsOpen(false)}
      />

      {/* Table Settings Modal */}
      <TableSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) => setSettings((s) => ({ ...s, ...newSettings }))}
        onReloadChips={handleReloadChips}
        onNewGame={startNewRound}
      />

      {/* Activity Logs Drawer */}
      <GameLogsDrawer
        logs={logs}
        isOpen={isLogsOpen}
        onClose={() => setIsLogsOpen(false)}
      />
    </div>
  );
}
