export type Suit = 'hearts' | 'diamonds' | 'clubs' | 'spades';
export type Rank = 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14; // 11=J, 12=Q, 13=K, 14=A

export interface Card {
  suit: Suit;
  rank: Rank;
  id: string;
}

export enum HandRankType {
  HIGH_CARD = 1,
  PAIR = 2,
  COLOR = 3,          // Flush
  SEQUENCE = 4,       // Normal Run / Straight
  PURE_SEQUENCE = 5,  // Straight Flush
  TRAIL = 6,          // Trio / Three of a Kind
}

export interface HandEvaluation {
  rankType: HandRankType;
  rankName: string;
  score: number;      // Primary composite score for comparison
  description: string;
  tieBreakers: number[]; // Ranks sorted for exact tie-breaking
}

export type PlayerStatus = 'active' | 'folded' | 'out';

export interface Player {
  id: string;
  name: string;
  avatar: string;
  isHuman: boolean;
  chips: number;
  currentBet: number;
  cards: Card[];
  isSeen: boolean;
  status: PlayerStatus;
  personality?: 'bluffer' | 'tight' | 'aggressive' | 'balanced';
  lastAction?: string;
}

export type GamePhase = 
  | 'idle' 
  | 'betting' 
  | 'sideshow_requested' 
  | 'showdown' 
  | 'round_ended';

export interface GameLog {
  id: string;
  timestamp: string;
  playerName: string;
  action: string;
  amount?: number;
  type: 'bet' | 'fold' | 'see' | 'show' | 'win' | 'info';
}

export interface SideshowRequest {
  fromPlayerId: string;
  toPlayerId: string;
}

export interface TableSettings {
  bootAmount: number;
  maxStake: number;
  botCount: 2 | 3 | 4;
  soundEnabled: boolean;
  gameSpeed: 'normal' | 'fast';
}
